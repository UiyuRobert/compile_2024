package BackEnd.Assembly;

public class SyscallAsm extends Asm {
    public SyscallAsm() {
        super();
    }

    @Override
    public String toString() {
        return "syscall\n";
    }
}
