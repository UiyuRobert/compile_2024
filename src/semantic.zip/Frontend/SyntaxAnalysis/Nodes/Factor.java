package Frontend.SyntaxAnalysis.Nodes;

public interface Factor {
    /*-- 求表达式值用 --*/
    int getValue();
}
