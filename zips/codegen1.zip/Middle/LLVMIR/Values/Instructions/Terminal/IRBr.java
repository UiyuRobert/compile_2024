package Middle.LLVMIR.Values.Instructions.Terminal;

import Middle.LLVMIR.Values.Instructions.IRInstruction;

/**
 *  `br i1 <cond>, label <iftrue>, label <iffalse>`
 *  `br label <dest>`
 * */
public class IRBr extends IRInstruction {
}
