package Middle.LLVMIR.IRTypes;

/**
 * llvm 返回值类型
 * */
public interface IRType {

}
