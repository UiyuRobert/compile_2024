package Frontend.SyntaxAnalysis.Nodes;

public interface Node {
    // void printParseResult(StringBuilder result);
}
