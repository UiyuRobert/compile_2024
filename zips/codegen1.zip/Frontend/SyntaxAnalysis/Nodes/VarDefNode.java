package Frontend.SyntaxAnalysis.Nodes;

import Frontend.LexicalAnalysis.Token;

import java.util.AbstractMap;
import java.util.Map;

public class VarDefNode implements Node {
    /*-- VarDef → Ident [ '[' ConstExp ']' ] | Ident [ '[' ConstExp ']' ] '=' InitVal --*/
    private Token identTerminal;
    private Token lbracketTerminal;
    private Node constExpNode;
    private Token rbracketTerminal;
    private Token assignTerminal;
    private Node initValNode;

    public VarDefNode(Token identTerminal, Token lbracketTerminal, Node constExpNode, Token rbracketTerminal) {
        this.identTerminal = identTerminal;
        this.lbracketTerminal = lbracketTerminal;
        this.constExpNode = constExpNode;
        this.rbracketTerminal = rbracketTerminal;
        this.assignTerminal = null;
        this.initValNode = null;
    }

    public VarDefNode(Token identTerminal, Token lbracketTerminal, Node constExpNode,
                      Token rbracketTerminal, Token assignTerminal, Node initValNode) {
        this.identTerminal = identTerminal;
        this.lbracketTerminal = lbracketTerminal;
        this.constExpNode = constExpNode;
        this.rbracketTerminal = rbracketTerminal;
        this.assignTerminal = assignTerminal;
        this.initValNode = initValNode;
    }

    public Map.Entry<String, Integer> getIdentifier() {
        return identTerminal.getIdentifier();
    }

    public boolean isArray() { return lbracketTerminal != null; }

    public int getArrayLength() { return ((ConstExpNode)constExpNode).getValue(); }

    public boolean hasAssign() { return assignTerminal != null; }

    public InitValNode getInitVal() { return (InitValNode)initValNode; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(identTerminal.toString());
        if (lbracketTerminal != null) {
            sb.append(lbracketTerminal).append(constExpNode.toString()).append(rbracketTerminal.toString());
        }
        if (assignTerminal != null) sb.append(assignTerminal).append(initValNode.toString());
        sb.append("<VarDef>\n");
        return sb.toString();
    }
}
